﻿//================================================


using CarrosAPI.Models;
using Microsoft.EntityFrameworkCore;

namespace CarrosAPI.Contexto  

{
    public class Contexto : DbContext
    {

        public Contexto(DbContextOptions<Contexto> options)
            : base(options) => Database.EnsureCreated();

        public DbSet<Produtos> Produto { get; set; }

    }
}


//=================================================