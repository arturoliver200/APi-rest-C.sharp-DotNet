
using CarrosAPI.Contexto;
using CarrosAPI.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
  

//=========================================================================================
//Banco SQL-server
builder.Services.AddDbContext<Contexto>
    (options => options.UseSqlServer(
        "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"));
//Banco ORACLE
//var stringConexao = "User Id=SYSTEM;Password=1234;Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST =localhost)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=XE)))";
//builder.Services.AddDbContext<Contexto>
//  (options => options.UseOracle(stringConexao));

//=====================================================================================
//Banco MySql -----
//builder.Services.AddDbContext<Contexto>  
//  (options => options.UseMySql(
//    "server=localhost;initial catalog=MINIMA_API_AULA;uid=root;pwd=1234",
//  Microsoft.EntityFrameworkCore.ServerVersion.Parse("8.0.25-mysql")));

//========================================================================================


builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();

app.MapPost("AdicionaProduto", async (Produtos produto, Contexto contexto) =>
{
    contexto.Produto.Add(produto);
    await contexto.SaveChangesAsync();
});

app.MapPost("ExcluirProduto/{id}", async (int id, Contexto contexto) =>
{
    var produtoExcluir = await contexto.Produto.FirstOrDefaultAsync(p => p.Id == id);
    if (produtoExcluir != null)
    {
        contexto.Produto.Remove(produtoExcluir);
        await contexto.SaveChangesAsync();
    }
});

app.MapPost("ListarProdutos", async (Contexto contexto) =>
{
    return await contexto.Produto.ToListAsync();
});

app.MapPost("ObterProduto/{id}", async (int id, Contexto contexto) =>
{
    return await contexto.Produto.FirstOrDefaultAsync(p => p.Id == id);
});


app.UseSwaggerUI();
app.Run();
