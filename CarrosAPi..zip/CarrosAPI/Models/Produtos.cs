﻿namespace CarrosAPI.Models
{
    public class Produtos
    {  
        public int Id { get; set; }   // Ecluir DB Sql e Criar um NOVO  "evita erro" 

        public string? Marca { get; set; }    

        public string? Modelo { get; set; }       
    }   
}
